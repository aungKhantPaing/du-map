
// Trig functions: https://unindented.org/articles/trigonometry-in-sass/
// Inspiration: https://sarasoueidan.com/blog/navicon-transformicons/

// document.getElementById('icon-1').addEventListener('click', function(){
//     classie.toggle(document.getElementById('dropdown-1'), 'close');
// });

// document.getElementById('icon-2').addEventListener('click', function(){
//     classie.toggle(document.getElementById('dropdown-2'), 'close');
// });

// var hasClass = function (elem, c) {
//     return elem.classList.contains(c);
// },
//     addClass = function (elem, c) {
//         elem.classList.add(c);
//     },
//     removeClass = function (elem, c) {
//         elem.classList.remove(c);
//     };

// function toggleClass(elem, c) {
//     var fn = hasClass(elem, c) ? removeClass : addClass;
//     fn(elem, c);
// }
// document.getElementById('icon-3').addEventListener('click', function () {
//     toggleClass(document.getElementById('dropdown-3'), 'close');
// });

// document.getElementById('icon-4').addEventListener('click', function(){
//     classie.toggle(document.getElementById('dropdown-4'), 'close');
// });

// document.getElementById('icon-5').addEventListener('click', function(){
//     classie.toggle(document.getElementById('menu-1'), 'close');
// });

// document.getElementById('icon-6').addEventListener('click', function(){
//     classie.toggle(document.getElementById('menu-2'), 'close');
// });

// document.getElementById('icon-7').addEventListener('click', function(){
//     classie.toggle(document.getElementById('menu-3'), 'close');
// });

// document.getElementById('icon-8').addEventListener('click', function(){
//     classie.toggle(document.getElementById('menu-4'), 'close');
// });

// document.getElementById('icon-9').addEventListener('click', function(){
//     classie.toggle(document.getElementById('submit-1'), 'close');
// });

// document.getElementById('icon-10').addEventListener('click', function(){
//     classie.toggle(document.getElementById('submit-2'), 'close');
// });

// document.getElementById('icon-11').addEventListener('click', function(){
//     classie.toggle(document.getElementById('submit-3'), 'close');
// });

// document.getElementById('icon-12').addEventListener('click', function(){
//     classie.toggle(document.getElementById('submit-4'), 'close');
// });